import pandas as pd
import numpy as np
from datetime import datetime, timedelta

np.random.seed(42)

NUM_ORDERS = 120   # >= 100 observations

couriers = ["Delhivery", "EcomExpress", "XpressBees"]
cities = ["Mumbai", "Delhi", "Bangalore", "Pune", "Jaipur"]
payment_types = ["COD", "Prepaid"]

start_date = datetime(2025, 6, 1)

rows = []

for i in range(NUM_ORDERS):
    order_date = start_date + timedelta(days=np.random.randint(0, 60))
    promised_days = np.random.choice([2, 3, 4])
    promised_date = order_date + timedelta(days=int(promised_days))


    courier = np.random.choice(couriers)
    city = np.random.choice(cities)
    payment = np.random.choice(payment_types, p=[0.6, 0.4])

    delay_probability = 0.15

    if courier == "XpressBees":
        delay_probability += 0.15
    if city in ["Jaipur"]:
        delay_probability += 0.10
    if payment == "COD":
        delay_probability += 0.05
    if order_date.weekday() >= 5:
        delay_probability += 0.10

    is_delayed = np.random.rand() < delay_probability

    if is_delayed:
        actual_delivery = promised_date + timedelta(days=np.random.randint(1, 3))
    else:
        actual_delivery = promised_date

    rows.append([
        f"ORD{i+1}",
        order_date.date(),
        promised_date.date(),
        actual_delivery.date(),
        courier,
        city,
        payment,
        order_date.weekday(),
        int(is_delayed)
    ])

df = pd.DataFrame(rows, columns=[
    "order_id",
    "order_date",
    "promised_date",
    "actual_delivery_date",
    "courier",
    "city",
    "payment_type",
    "order_weekday",
    "delay"
])

df.to_csv("orders.csv", index=False)

print("✅ orders.csv generated with", len(df), "rows")
