# DelayShield

AI app to predict delivery delays before shipment.