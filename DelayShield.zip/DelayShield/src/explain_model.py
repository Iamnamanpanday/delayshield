import joblib
import shap
import pandas as pd

# -----------------------------
# LOAD MODEL
# -----------------------------
pipeline = joblib.load("models/xgboost_pipeline.pkl")

# -----------------------------
# LOAD DATA
# -----------------------------
df = pd.read_csv("data/orders.csv")

# Feature engineering (MUST MATCH TRAINING)
courier_delay_rate = df.groupby("courier")["delay"].mean()
df["courier_delay_rate"] = df["courier"].map(courier_delay_rate)

X = df.drop(columns=["delay", "order_id", "actual_delivery_date"])

# -----------------------------
# GET TRANSFORMED FEATURES
# -----------------------------
preprocessor = pipeline.named_steps["preprocess"]
model = pipeline.named_steps["model"]

X_transformed = preprocessor.transform(X)

# Feature names
cat_features = preprocessor.named_transformers_["cat"].get_feature_names_out()
num_features = ["order_weekday", "courier_delay_rate"]
feature_names = list(cat_features) + num_features

# -----------------------------
# SHAP EXPLAINER
# -----------------------------
explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_transformed)

# -----------------------------
# EXPLAIN SINGLE ORDER
# -----------------------------
def explain_order(index):
    values = shap_values[index]
    explanation = dict(zip(feature_names, values))
    return explanation

# Example
print("🔍 SHAP explanation for order 0:")
print(explain_order(0))
