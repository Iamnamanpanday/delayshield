import joblib
import os

# -----------------------------
# 11. SAVE MODEL
# -----------------------------
os.makedirs("models", exist_ok=True)

joblib.dump(pipeline, "models/xgboost_pipeline.pkl")

print("✅ Model saved to models/xgboost_pipeline.pkl")
