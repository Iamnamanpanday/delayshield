import pandas as pd
import numpy as np

from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
from sklearn.preprocessing import OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.pipeline import Pipeline

from xgboost import XGBClassifier

# -----------------------------
# 1. LOAD DATA
# -----------------------------
df = pd.read_csv("C:\\Users\\Naman\\Desktop\\DelayShield\\data\\orders.csv")

# -----------------------------
# 2. FEATURE ENGINEERING
# -----------------------------

# Courier reliability feature (VERY IMPORTANT)
courier_delay_rate = df.groupby("courier")["delay"].mean()
df["courier_delay_rate"] = df["courier"].map(courier_delay_rate)

X = df.drop(columns=["delay", "order_id", "actual_delivery_date"])
y = df["delay"]

categorical_cols = ["courier", "city", "payment_type"]
numeric_cols = ["order_weekday", "courier_delay_rate"]

# -----------------------------
# 3. PREPROCESSING
# -----------------------------
preprocessor = ColumnTransformer(
    transformers=[
        ("cat", OneHotEncoder(handle_unknown="ignore"), categorical_cols),
        ("num", "passthrough", numeric_cols)
    ]
)

# -----------------------------
# 4. TRAIN / TEST SPLIT
# -----------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y,
    test_size=0.2,
    stratify=y,
    random_state=42
)

# -----------------------------
# 5. HANDLE CLASS IMBALANCE
# -----------------------------
num_non_delay = (y_train == 0).sum()
num_delay = (y_train == 1).sum()

scale_pos_weight = num_non_delay / num_delay

# -----------------------------
# 6. MODEL
# -----------------------------
model = XGBClassifier(
    n_estimators=300,
    max_depth=4,
    learning_rate=0.05,
    scale_pos_weight=scale_pos_weight,
    subsample=0.8,
    colsample_bytree=0.8,
    eval_metric="logloss",
    random_state=42
)

# -----------------------------
# 7. PIPELINE
# -----------------------------
pipeline = Pipeline(
    steps=[
        ("preprocess", preprocessor),
        ("model", model)
    ]
)

# -----------------------------
# 8. TRAIN
# -----------------------------
pipeline.fit(X_train, y_train)

# -----------------------------
# 9. PREDICT WITH LOWER THRESHOLD
# -----------------------------
y_probs = pipeline.predict_proba(X_test)[:, 1]

# IMPORTANT: lower threshold to catch more delays
threshold = 0.35
y_pred = (y_probs >= threshold).astype(int)

# -----------------------------
# 10. EVALUATION
# -----------------------------
print("Classification Report (Threshold = 0.35)")
print(classification_report(y_test, y_pred))

import joblib
import os

# create models directory if it doesn't exist
os.makedirs("models", exist_ok=True)

joblib.dump(pipeline, "models/xgboost_pipeline.pkl")
print("✅ Model saved to models/xgboost_pipeline.pkl")
