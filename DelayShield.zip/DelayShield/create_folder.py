import os

folders = [
    "data/raw",
    "data/processed",
    "notebooks",
    "src/data",
    "src/models",
    "src/utils",
    "app",
    "reports/figures"
]

files = {
    "src/data/generate_data.py": "",
    "src/models/train_model.py": "",
    "src/utils/helpers.py": "",
    "app/app.py": "",
    "README.md": "# DelayShield\n\nAI app to predict delivery delays before shipment.",
    "requirements.txt": "pandas\nnumpy\nscikit-learn\nxgboost\nstreamlit\nshap\nmatplotlib\n",
    ".gitignore": "__pycache__/\n.env\n*.csv\n"
}

for folder in folders:
    os.makedirs(folder, exist_ok=True)

for file, content in files.items():
    with open(file, "w") as f:
        f.write(content)

print("✅ DelayShield project structure created successfully")
