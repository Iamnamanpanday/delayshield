import streamlit as st
import pandas as pd
import numpy as np
import joblib
import matplotlib.pyplot as plt

# --------------------------------
# PAGE CONFIG
# --------------------------------
st.set_page_config(
    page_title="DelayShield",
    page_icon="🚚",
    layout="wide"
)

# --------------------------------
# THEME TOGGLE
# --------------------------------
theme = st.sidebar.radio(
    "🎨 Theme",
    ["Light", "Dark"]
)

if theme == "Dark":
    st.markdown(
        """
        <style>
        body { background-color: #0e1117; color: white; }
        </style>
        """,
        unsafe_allow_html=True
    )

# --------------------------------
# HEADER
# --------------------------------
st.title("🚚 DelayShield")
st.caption("AI-powered delivery delay prediction **before shipment**")

st.markdown("""
**What this app does**
- Predicts delivery delay risk *before* shipping
- Explains *why* an order may be delayed
- Helps sellers take preventive action
""")

st.divider()

# --------------------------------
# LOAD MODEL
# --------------------------------
@st.cache_resource
def load_model():
    return joblib.load("models/xgboost_pipeline.pkl")

pipeline = load_model()

# --------------------------------
# FILE UPLOAD
# --------------------------------
st.subheader("📤 Upload Order & Courier Data")

uploaded_file = st.file_uploader(
    "Upload CSV file (orders & courier data)",
    type=["csv"],
    help="Required columns: order_id, courier, city, payment_type, order_weekday"
)

if uploaded_file is None:
    st.info("⬆️ Upload a CSV file to start delay risk prediction.")
    st.stop()

df = pd.read_csv(uploaded_file)

# --------------------------------
# FEATURE ENGINEERING
# --------------------------------
st.subheader("⚙️ Processing Orders")

courier_delay_rate = df.groupby("courier")["delay"].mean()
df["courier_delay_rate"] = df["courier"].map(courier_delay_rate)

X = df.drop(columns=["delay", "order_id", "actual_delivery_date"], errors="ignore")

# --------------------------------
# PREDICTIONS
# --------------------------------
probs = pipeline.predict_proba(X)[:, 1]
threshold = 0.35

df["delay_risk"] = probs
df["risk_label"] = np.where(probs >= threshold, "High Risk", "Low Risk")

# --------------------------------
# KPI METRICS
# --------------------------------
st.subheader("📊 Key Metrics")

col1, col2, col3 = st.columns(3)

with col1:
    st.metric("Total Orders", len(df))

with col2:
    st.metric(
        "High Risk Orders",
        int((df["delay_risk"] >= threshold).sum())
    )

with col3:
    st.metric(
        "Average Delay Risk",
        f"{df['delay_risk'].mean():.2f}"
    )

st.divider()

# --------------------------------
# RISK DISTRIBUTION GRAPH
# --------------------------------
st.subheader("📈 Delay Risk Distribution")

fig, ax = plt.subplots()
ax.hist(df["delay_risk"], bins=20, color="#1f77b4", edgecolor="black")
ax.axvline(threshold, color="red", linestyle="--", label="High Risk Threshold")
ax.set_xlabel("Delay Risk Probability")
ax.set_ylabel("Number of Orders")
ax.legend()

st.pyplot(fig)

# --------------------------------
# ORDER LEVEL VIEW
# --------------------------------
st.subheader("📦 Order-Level Risk Analysis")

st.markdown("**High Risk Orders (sorted)**")

high_risk_df = df[df["delay_risk"] >= threshold].sort_values(
    by="delay_risk", ascending=False
)

st.dataframe(
    high_risk_df[
        ["order_id", "courier", "city", "delay_risk", "risk_label"]
    ],
    use_container_width=True
)

# --------------------------------
# INSIGHTS SECTION
# --------------------------------
st.subheader("🧠 Insights")

worst_couriers = (
    df.groupby("courier")["delay_risk"]
    .mean()
    .sort_values(ascending=False)
    .head(3)
)

st.markdown("**Couriers with highest delay risk:**")
st.write(worst_couriers)

st.markdown("""
**Suggested Actions**
- Consider switching courier for high-risk zones
- Dispatch earlier for weekend orders
- Notify customers proactively for risky deliveries
""")

st.divider()

# --------------------------------
# FOOTER
# --------------------------------
st.caption("DelayShield v0 • Decision-support system • No auto-trading or automation")
